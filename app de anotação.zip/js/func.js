$(function(){
		abrirJanela()
		fechaJanela()
		function abrirJanela(){
			$('nav h1').click(function(e){
				e.stopPropagation()
				$('ul').fadeIn();
			})
		}

		function fechaJanela(){
			$('body').click(function(){
				$('ul').fadeOut()
			})
		}
			$(".btn-add").click(function(){
				var el = '<div class="anotacao-single"><textarea placeholder="sua nova anotação" id="registro"></textarea></div>';
				$('.container-anotacoes').append(el);


					var textArea = $('.anotacao-single').last().find('textarea');

					var date = new Date();
					var hh = date.getHours();
					var mm = date.getMinutes();

					var finalTime = hh+":"+mm;

					textArea.html('Nova anotação as '+finalTime);

			})

			$(".btn-add").click(function(){
			
					$('.butao button').toggle();
			})

		})

class Registros{
	constructor(registro){
		this.registro = registro
	}
}

class Bd{
	constructor(){
		let id = localStorage.getItem('id')

		if(id === null){
			localStorage.setItem('id', 0)
		}
	}
	getProximoId(){
		let proximoId = localStorage.getItem('id')
		return parseInt(proximoId) + 1
	}

	gravar(c){
		let id = this.getProximoId()

		localStorage.setItem(id, JSON.stringify(c))

		localStorage.setItem('id', id)
	}

	recuperarTodosConteudos(){

		let registros = Array()
		let id = localStorage.getItem('id')

		for(let i = 1; i <= id; i++){

			let registro = JSON.parse(localStorage.getItem(i))

			if(registro === null){
				continue
			}

			registros.push(registro)
		}

		return registros
	}
}

let bd = new Bd()

function salvaConteudo(){
	let registro = document.getElementById('registro')

	let conteudo = new Registros(registro.value)
	bd.gravar(conteudo)

	alert('Sua anotação foi salva com succeso!!!')

	window.location.reload()
}

function carregaConteudo(){

	let registros = Array()

	registros = bd.recuperarTodosConteudos()

	let minhas_anotacoes = document.getElementById('minhas-anotacoes')

	registros.forEach(function(r){
		minhas_anotacoes.insertRow().innerHTML = r.registro

	})
}
